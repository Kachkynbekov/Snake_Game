package com.company;

import java.awt.*;

public class Entity {
    private int x,y,size;
    public Entity(int size){
        this.size = size;
    }

    public int getX() {
        return x;
    }

    public int getY() {
        return y;
    }

    public void setX(int x) {
        this.x = x;
    }

    public void setY(int y) {
        this.y = y;
    }
    public void setPosition(int x, int y){
        this.x = x;
        this.y = y;
    }
    public void move(int dx, int dy){
        x += dx;
        y += dy;
    }
    public Rectangle getBounds(){
        return new Rectangle(x,y,size,size);
    }
    public boolean isCollsion(Entity o){
        if (o == this) return false;
        return getBounds().intersects(o.getBounds());
    }
    public void render(Graphics2D g2d){
        g2d.fillRect(x,y,size,size);
    }
}
